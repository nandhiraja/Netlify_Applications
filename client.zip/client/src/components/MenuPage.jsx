import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './Styles/MenuPage.css';
import { IoMdArrowRoundBack } from "react-icons/io";

const BASE_URL = import.meta.env.VITE_Base_url;

const MenuPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const orderType = location.state?.orderType || 'dine-in';
  
  const [allMenuData, setAllMenuData] = useState(null); // Store entire response
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleCardClick = (category) => {
    // Filter items for this category
    const categoryItems = allMenuData.items.filter(
      item => item.categoryId === category.categoryId
    );
    
    // Navigate with all necessary data
    navigate(`/item/${category.categoryId}`, { 
      state: { 
        category,
        items: categoryItems,
        itemTags: allMenuData.itemTags,
        taxTypes: allMenuData.taxTypes,
        charges: allMenuData.charges,
        discounts: allMenuData.discounts,
        orderType 
      } 
    });
  };

  const handleBackClick = () => {
    navigate('/');
  };

  useEffect(() => {
    console.log("Fetching category data from backend...", BASE_URL);
    
    fetch(`${BASE_URL}/catalog/?channel=Palas Kiosk`, {
     headers: {
       "ngrok-skip-browser-warning": "true"
     }
      })
      .then(async (response) => {
        let raw = await response.text();
        console.log("Status:", response.status ,raw);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
  
        const data = await JSON.parse(raw);
        
        // Store all data
        setAllMenuData(data);
        setCategories(data.categories);
        setLoading(false);
        
        console.log("Menu data received:", data);
      })
      .catch((err) => {
        console.error("Error fetching category data:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="menu-container"><p>Loading menu...</p></div>;
  }

  return (
    <div className="menu-container">
      {/* Header Section */}
      <div className="menu-header">
        <button className="back-button" onClick={handleBackClick}>
          <IoMdArrowRoundBack/>
        </button>
        <h1 className="menu-title">Menu</h1>
        <div className="order-type-badge">
          {orderType === 'dine-in' ? 'Dine In' : 'Take Away'}
        </div>
      </div>

      {/* Menu Grid */}
      <div className="menu-grid">
        {categories.map((category) => (
          <div 
            key={category.categoryId} 
            className="menu-card"
            onClick={() => handleCardClick(category)}
          >
            <div className="card-image-wrapper">
              <img 
                src={category.imageUrl ||  './placeholder.jpg'}
                alt={category.name}
                className="card-image"
                onError={(e) => {
                  e.target.src = '/home/nandhiraja/Nandhiraja C/Naveen Nk project/restaurant-kiosk-frontend/client/public/Images/spaghetti-carbonara.png'; // Fallback image
                }}
              />
              <div className="card-overlay"></div>
            </div>
            <div className="card-content">
              <h3 className="card-title">{category.name}</h3>
            </div>
            <div className="card-shine"></div>
          </div>
        ))}
      </div>

      <footer className="menu-footer">
        <div className="footer-content">
          <p className="footer-text">Scroll to explore more delicious items</p>
          <div className="footer-decorative-line"></div>
        </div>
      </footer>
    </div>
  );
};

export default MenuPage;
